// // Popup basket

// let basketContentButtonItemsButton = document.querySelector('.basket-content_button_items_button');
// let popup = document.querySelector('.popup');

// basketContentButtonItemsButton.onclick = function() {
//     popup.style.display = 'flex';
// }

// window.onclick = function(event) {
//     if (event.target === popup) {
//         popup.style.display = 'none';
//     }
// }
document.addEventListener("DOMContentLoaded", function() {
  document.querySelectorAll(".btn-catalog").forEach(container => {
      let btn = container.querySelector("button");
      if (btn) {
          btn.addEventListener("click", function(e) {
              e.stopPropagation(); 
              container.classList.toggle("active-btn");
              btn.textContent = container.classList.contains("active-btn") ? "В корзине" : "В корзину";
          });
      }
  });
});
document.getElementById('sortSelect').addEventListener('change', function () {
  const sortType = this.value;
  const container = document.querySelector('.dtk-catalog__objects_products');
  const products = Array.from(container.querySelectorAll('.product'));

  let sortedProducts = [...products];

  if (sortType === 'price-asc') {
      sortedProducts.sort((a, b) => getPrice(a) - getPrice(b));
  } else if (sortType === 'price-desc') {
      sortedProducts.sort((a, b) => getPrice(b) - getPrice(a));
  } else if (sortType === 'name-asc') {
      sortedProducts.sort((a, b) => getName(a).localeCompare(getName(b)));
  } else if (sortType === 'name-desc') {
      sortedProducts.sort((a, b) => getName(b).localeCompare(getName(a)));
  } else {
      sortedProducts = products; 
  }

  container.innerHTML = '';
  sortedProducts.forEach(product => container.appendChild(product));
});

function getPrice(product) {
  const priceText = product.querySelector('.product-content-price p').textContent.replace(/[^\d]/g, '');
  return parseInt(priceText, 10);
}

function getName(product) {
  return product.querySelector('.product-content-description-text p').textContent.trim();
}




function filterByPlatform(platform) {
  const products = document.querySelectorAll('.product');

  products.forEach(product => {
      const productPlatform = product.getAttribute('data-platform');

      if (platform === 'all') {
          product.style.display = 'block';
      } else {
          
          const platforms = productPlatform.split(' ');
          if (platforms.includes(platform)) {
              product.style.display = 'block';
          } else {
              product.style.display = 'none';
          }
      }
  });
}